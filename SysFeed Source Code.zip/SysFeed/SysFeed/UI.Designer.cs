﻿namespace SysFeed
{
    partial class UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UI));
            this.SysFeed = new System.IO.FileSystemWatcher();
            this.Output = new System.Windows.Forms.RichTextBox();
            this.OutputNum = new System.Windows.Forms.StatusStrip();
            this.DelNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.ChangeNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.RenameNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CreatedNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.Menu = new System.Windows.Forms.ToolStripDropDownButton();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetOutputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetEventCountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.githubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.SysFeed)).BeginInit();
            this.OutputNum.SuspendLayout();
            this.SuspendLayout();
            // 
            // SysFeed
            // 
            this.SysFeed.EnableRaisingEvents = true;
            this.SysFeed.IncludeSubdirectories = true;
            this.SysFeed.NotifyFilter = ((System.IO.NotifyFilters)((((System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.DirectoryName) 
            | System.IO.NotifyFilters.LastWrite) 
            | System.IO.NotifyFilters.Security)));
            this.SysFeed.Path = "C:/";
            this.SysFeed.SynchronizingObject = this;
            this.SysFeed.Changed += new System.IO.FileSystemEventHandler(this.SysFeed_Changed);
            this.SysFeed.Created += new System.IO.FileSystemEventHandler(this.SysFeed_Created);
            this.SysFeed.Deleted += new System.IO.FileSystemEventHandler(this.SysFeed_Deleted);
            this.SysFeed.Renamed += new System.IO.RenamedEventHandler(this.SysFeed_Renamed);
            // 
            // Output
            // 
            this.Output.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.Output.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Output.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Output.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.Output.ForeColor = System.Drawing.Color.White;
            this.Output.Location = new System.Drawing.Point(0, 0);
            this.Output.Name = "Output";
            this.Output.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.Output.Size = new System.Drawing.Size(974, 632);
            this.Output.TabIndex = 1;
            this.Output.Text = "Output";
            // 
            // OutputNum
            // 
            this.OutputNum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.OutputNum.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.OutputNum.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DelNum,
            this.ChangeNum,
            this.RenameNum,
            this.toolStripStatusLabel1,
            this.CreatedNum,
            this.Menu});
            this.OutputNum.Location = new System.Drawing.Point(0, 600);
            this.OutputNum.Name = "OutputNum";
            this.OutputNum.Size = new System.Drawing.Size(974, 32);
            this.OutputNum.TabIndex = 2;
            this.OutputNum.Text = "statusStrip1";
            // 
            // DelNum
            // 
            this.DelNum.ForeColor = System.Drawing.Color.White;
            this.DelNum.Name = "DelNum";
            this.DelNum.Size = new System.Drawing.Size(100, 25);
            this.DelNum.Text = "Deleted - 0";
            // 
            // ChangeNum
            // 
            this.ChangeNum.ForeColor = System.Drawing.Color.White;
            this.ChangeNum.Name = "ChangeNum";
            this.ChangeNum.Size = new System.Drawing.Size(110, 25);
            this.ChangeNum.Text = "Changed - 0";
            // 
            // RenameNum
            // 
            this.RenameNum.ForeColor = System.Drawing.Color.White;
            this.RenameNum.Name = "RenameNum";
            this.RenameNum.Size = new System.Drawing.Size(113, 25);
            this.RenameNum.Text = "Renamed - 0";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 25);
            // 
            // CreatedNum
            // 
            this.CreatedNum.ForeColor = System.Drawing.Color.White;
            this.CreatedNum.Name = "CreatedNum";
            this.CreatedNum.Size = new System.Drawing.Size(100, 25);
            this.CreatedNum.Text = "Created - 0";
            // 
            // Menu
            // 
            this.Menu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Menu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.applicationToolStripMenuItem});
            this.Menu.ForeColor = System.Drawing.Color.White;
            this.Menu.Image = ((System.Drawing.Image)(resources.GetObject("Menu.Image")));
            this.Menu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Menu.Name = "Menu";
            this.Menu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Menu.Size = new System.Drawing.Size(94, 29);
            this.Menu.Text = "Options";
            this.Menu.ToolTipText = "Options";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetOutputToolStripMenuItem,
            this.resetEventCountToolStripMenuItem,
            this.resetAllToolStripMenuItem});
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.clearToolStripMenuItem.Text = "Clear";
            // 
            // resetOutputToolStripMenuItem
            // 
            this.resetOutputToolStripMenuItem.Name = "resetOutputToolStripMenuItem";
            this.resetOutputToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.resetOutputToolStripMenuItem.Text = "Reset Output";
            this.resetOutputToolStripMenuItem.Click += new System.EventHandler(this.resetOutputToolStripMenuItem_Click);
            // 
            // resetEventCountToolStripMenuItem
            // 
            this.resetEventCountToolStripMenuItem.Name = "resetEventCountToolStripMenuItem";
            this.resetEventCountToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.resetEventCountToolStripMenuItem.Text = "Reset Event Count";
            this.resetEventCountToolStripMenuItem.Click += new System.EventHandler(this.resetEventCountToolStripMenuItem_Click);
            // 
            // resetAllToolStripMenuItem
            // 
            this.resetAllToolStripMenuItem.Name = "resetAllToolStripMenuItem";
            this.resetAllToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.resetAllToolStripMenuItem.Text = "Reset All";
            this.resetAllToolStripMenuItem.Click += new System.EventHandler(this.resetAllToolStripMenuItem_Click);
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restartToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.informationToolStripMenuItem,
            this.githubToolStripMenuItem});
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.applicationToolStripMenuItem.Text = "Application";
            // 
            // restartToolStripMenuItem
            // 
            this.restartToolStripMenuItem.Name = "restartToolStripMenuItem";
            this.restartToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.restartToolStripMenuItem.Text = "Restart";
            this.restartToolStripMenuItem.Click += new System.EventHandler(this.restartToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // informationToolStripMenuItem
            // 
            this.informationToolStripMenuItem.Name = "informationToolStripMenuItem";
            this.informationToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.informationToolStripMenuItem.Text = "Information";
            this.informationToolStripMenuItem.Click += new System.EventHandler(this.informationToolStripMenuItem_Click);
            // 
            // githubToolStripMenuItem
            // 
            this.githubToolStripMenuItem.Name = "githubToolStripMenuItem";
            this.githubToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.githubToolStripMenuItem.Text = "Github";
            this.githubToolStripMenuItem.Click += new System.EventHandler(this.githubToolStripMenuItem_Click);
            // 
            // UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 632);
            this.Controls.Add(this.OutputNum);
            this.Controls.Add(this.Output);
            this.Name = "UI";
            this.ShowIcon = false;
            this.Text = "SysFeed";
            this.Load += new System.EventHandler(this.UI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SysFeed)).EndInit();
            this.OutputNum.ResumeLayout(false);
            this.OutputNum.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.IO.FileSystemWatcher SysFeed;
        private System.Windows.Forms.RichTextBox Output;
        private System.Windows.Forms.StatusStrip OutputNum;
        private System.Windows.Forms.ToolStripStatusLabel DelNum;
        private System.Windows.Forms.ToolStripStatusLabel ChangeNum;
        private System.Windows.Forms.ToolStripStatusLabel RenameNum;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel CreatedNum;
        private System.Windows.Forms.ToolStripDropDownButton Menu;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetOutputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetEventCountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem githubToolStripMenuItem;
    }
}

