﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysFeed
{
    public partial class UI : Form
    {
        public int _change = 0;
        public int _create = 0;
        public int _delete = 0;
        public int _rename = 0;

        public UI()
        {
            InitializeComponent();
        }
        private void SysFeed_Changed(object sender, FileSystemEventArgs e)
        {
            _change++;

            ChangeNum.Text = "Changed - " + _create.ToString();

            Output.Text += Environment.NewLine + "";
            Output.Text += Environment.NewLine + "Changed - " + Environment.NewLine + "Name: " +  e.Name + Environment.NewLine + "Path: " + e.FullPath;
        }
        private void SysFeed_Created(object sender, FileSystemEventArgs e)
        {
            _create++;

            CreatedNum.Text = "Created - " + _create.ToString();

            Output.Text += Environment.NewLine + "";
            Output.Text += Environment.NewLine + "Created - " + Environment.NewLine + "Name: " + e.Name + Environment.NewLine + "Path: " + e.FullPath;
        }
        private void SysFeed_Deleted(object sender, FileSystemEventArgs e)
        {
            _delete++;

            DelNum.Text = "Deleted - " + _delete.ToString();

            Output.Text += Environment.NewLine + "";
            Output.Text += Environment.NewLine + "Deleted - " + Environment.NewLine + "Name: " + e.Name + Environment.NewLine + "Path: " + e.FullPath;
        }
        private void SysFeed_Renamed(object sender, FileSystemEventArgs e)
        {
            _rename++;

            RenameNum.Text = "Renamed - " + _rename.ToString();

            Output.Text += Environment.NewLine + "";
            Output.Text += Environment.NewLine + "Renamed - " + Environment.NewLine + "Name: " + e.Name + Environment.NewLine + "Path: " + e.FullPath;
        }
        private void UI_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();

            var Path = "C:/";

            SysFeed.Path = Path;
            SysFeed.EnableRaisingEvents = true;

            this.ShowInTaskbar = false;
            this.ShowIcon = false;
            this.TopMost = false;

            Output.Text = Application.ProductName + " " + Application.ProductVersion;
        }
        //Drop Down
        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void informationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name - " + Application.ProductName + ", Version - " + Application.ProductVersion);
        }
        private void githubToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("https://github.com/WillHick/SysFeed");
        }
        private void resetOutputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Output.ResetText();
        }
        private void resetEventCountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DelNum.Text = "Deleted - ";
            ChangeNum.Text = "Changed - ";
            RenameNum.Text = "Renamed - ";
            CreatedNum.Text = "Created - ";
        }
        private void resetAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Output.Text = Application.ProductName + " " + Application.ProductVersion;

            DelNum.Text = "Deleted - ";
            ChangeNum.Text = "Changed - ";
            RenameNum.Text = "Renamed - ";
            CreatedNum.Text = "Created - ";

            Output.ResetText();
        }
    }
}
